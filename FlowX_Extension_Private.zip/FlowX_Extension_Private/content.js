// FlowX Content Script — Auto-injects on flow.google.com
'use strict';

/* ─────────────────────────────────────────────────────────
   FLASH PREVENTER
   Hides the page IMMEDIATELY (before any React paint) so
   users never see the old/default UI during initialisation.
   revealPage() removes this once transforms are applied.
───────────────────────────────────────────────────────── */
; (function injectFlashPreventer() {
  try {
    const s = document.createElement('style');
    s.id = 'flowx-fp';
    // Hide the entire body; transitions disabled so no fade-in of old UI
    s.textContent = 'body{visibility:hidden!important;transition:none!important}';
    (document.head || document.documentElement).appendChild(s);
    // Safety valve: always reveal after 3 s even if init fails
    window.__flowxFPTimer = setTimeout(() => {
      const el = document.getElementById('flowx-fp');
      if (el) el.remove();
    }, 3000);
  } catch (_) { }
})();

/* ─────────────────────────────────────────────────────────
   CONFIG — Updated from storage
───────────────────────────────────────────────────────── */
let FLOWX = {
  enabled: true,
  whatsappNumber: '923001234567',
  whatsappLink: 'https://wa.me/923001234567',
  adminName: 'Admin',
};

// WeakMap: node → the value WE set it to last.
// Using WeakMap (not WeakSet) so we can detect when React resets the text
// back to the original and re-apply our replacement.
const processedTextNodes = new WeakMap();


/* ─────────────────────────────────────────────────────────
   TEXT REPLACEMENT MAP
   CRITICAL ORDER:
   1. Full model-name patterns (no partial word clash)
   2. PRO → ULTRA badge
   3. Button renames
───────────────────────────────────────────────────────── */
/* ─────────────────────────────────────────────────────────
   TEXT REPLACEMENT MAP
   CRITICAL ORDER:
   1. Full model-name patterns (catches model selector, Video Info full strings)
   2. Flexible-dash variants (catches different dash/space rendering)
   3. API-format identifiers (veo-3.1-lite etc)
   4. PRO → ULTRA badge
   5. Button renames
   6. Download labels
   NOTE: Standalone 'Lite'/'Fast' patterns are LAST to avoid false positives.
         processModelNamesElementLevel() handles split-element Video Info cases.
───────────────────────────────────────────────────────── */
const TEXT_RULES = [
  // ── Full model name (exact, uppercase 'Veo') ──
  // Lowercase 'veo' in output keeps hideQualityModel safe.
  { pattern: /Veo 3\.1 - Fast/g, replacement: 'veo 3.1 - Quality' },
  { pattern: /Veo 3\.1 - Lite/g, replacement: 'veo 3.1 - Fast' },
  // ── Flexible-dash variants (en-dash, em-dash, no-space) ──
  // Catches 'Veo 3.1–Fast', 'Veo 3.1-Lite', etc.
  { pattern: /Veo\s+3\.1\s*[-–—]\s*Fast\b/g, replacement: 'veo 3.1 - Quality' },
  { pattern: /Veo\s+3\.1\s*[-–—]\s*Lite\b/g, replacement: 'veo 3.1 - Fast' },
  // ── API / internal identifiers ──
  { pattern: /\bveo-3\.1-flash\b/gi, replacement: 'veo 3.1 - Quality' },
  { pattern: /\bveo-3\.1-lite\b/gi, replacement: 'veo 3.1 - Fast' },
  { pattern: /\bveo-3\.1-fast\b/gi, replacement: 'veo 3.1 - Quality' },
  // ── PRO badge → ULTRA ──
  { pattern: /\bPRO\b/g, replacement: 'ULTRA' },
  // ── Button text ──
  { pattern: /\bGenerate Video\b/gi, replacement: 'Create' },
  { pattern: /\bStart Creating\b/gi, replacement: 'New Project' },
  // ── Download resolution labels (video) ──
  // NOTE: lowercase 'k' so these don't clash with uppercase '4K' Upgrade row.
  { pattern: /\b270p\b/g, replacement: 'Gif' },
  { pattern: /\b720p\b/g, replacement: '1k' },
  { pattern: /\b1080p\b/g, replacement: '4k' },
  // ── Image download labels ──
  // ORDER IS CRITICAL: 2K→4K must come BEFORE 1K→2K to prevent chain-rename.
  { pattern: /\b2K\b/g, replacement: '4K' },
  { pattern: /\b1K\b/g, replacement: '2K' },
];

/* ─────────────────────────────────────────────────────────
   QUALITY MODEL HIDER
   Tracks elements whose list-item container is hidden.
   Must run BEFORE text replacements so we catch the
   *original* "Veo 3.1 - Quality" before Fast gets renamed.
───────────────────────────────────────────────────────── */
const hiddenQualityElements = new WeakSet();

function hideQualityModel(root) {
  const walker = document.createTreeWalker(
    root,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        // Skip nodes WE renamed — their stored value equals current content
        const stored = processedTextNodes.get(node);
        if (stored !== undefined && stored === node.textContent) return NodeFilter.FILTER_SKIP;
        const p = node.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        const tag = p.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  let node;
  while ((node = walker.nextNode())) {
    // Only match EXACTLY "Veo 3.1 - Quality" (not our renamed ones)
    if (!/Veo\s*3\.1\s*-\s*Quality/.test(node.textContent)) continue;

    // Walk UP the DOM to find the list-item / option container
    let container = node.parentElement;
    for (let i = 0; i < 8; i++) {
      if (!container || container === document.body) break;
      const role = container.getAttribute('role') || '';
      const tag = container.tagName;
      // Natural list-item signals
      if (tag === 'LI' || role === 'option' || role === 'menuitem' || role === 'listitem') break;
      // If the parent has 3+ same-tag siblings → we're inside a list item
      const parent = container.parentElement;
      if (parent && parent !== document.body) {
        const sibs = Array.from(parent.children);
        if (sibs.length >= 3 && sibs.every(s => s.tagName === container.tagName) && container.tagName !== 'SPAN') break;
      }
      container = container.parentElement;
    }

    if (!container || hiddenQualityElements.has(container)) continue;
    hiddenQualityElements.add(container);
    container.style.setProperty('display', 'none', 'important');
    container.setAttribute('data-flowx-quality-hidden', '1');
  }
}

/* ─────────────────────────────────────────────────────────
   SELECTORS — Elements to watch / modify
───────────────────────────────────────────────────────── */
// Selectors for the "credits" pill / text (the one showing "X credits")
const CREDITS_SELECTORS = [
  '[data-testid*="credit"]',
  '[class*="credit"]',
  '[aria-label*="credit"]',
  'button[aria-label*="credit"]',
];

// Text patterns that indicate a credits display
const CREDITS_TEXT_PATTERNS = [
  /Generating will use \d+ credits/i,
  /\d+ credits? remaining/i,
  /\d+ credits?/i,
  /credits? balance/i,
];

/* ─────────────────────────────────────────────────────────
   LOAD SETTINGS
───────────────────────────────────────────────────────── */
function loadSettings() {
  chrome.storage.local.get(null, (settings) => {
    if (settings) {
      FLOWX = { ...FLOWX, ...settings };
    }
    if (FLOWX.enabled) {
      init();
    }
  });
}

/* ─────────────────────────────────────────────────────────
   INIT
───────────────────────────────────────────────────────── */
function init() {
  injectTopBanner();
  injectWatermark();
  injectModal();

  // Start observer and interval EARLY — they catch React mutations
  // as the app renders, applying transforms on the fly.
  startObserver();
  startIntervalSweep();

  // DO NOT reveal immediately. Wait until Google Flow's React app has
  // actually rendered content, THEN transform + reveal.
  waitForAppReady(() => {
    runTransformations();
    // One rAF: let transforms paint before body becomes visible
    requestAnimationFrame(revealPage);
  });
}

/* ─────────────────────────────────────────────────────────
   WAIT FOR APP READY
   Polls via requestAnimationFrame until Google Flow's React
   app has rendered meaningful content (models, nav, input).
   Only then do we transform + reveal.

   This is the initialization gate the user requires:
     isInitializing=true  → body hidden, waiting
     React renders        → observer applies transforms live
     content detected     → runTransformations() + reveal
     isInitializing=false → page visible with correct UI
───────────────────────────────────────────────────────── */
function waitForAppReady(callback) {
  const MAX_WAIT_MS = 5000;
  const start = Date.now();

  // Signals that Google Flow has rendered its main UI:
  function isFlowReady() {
    if (!document.body) return false;
    const txt = document.body.textContent || '';
    return (
      // Model names present → React rendered the header/model selector
      txt.includes('Veo') || txt.includes('Omni') ||
      // Navigation sidebar rendered
      txt.includes('All media') || txt.includes('Characters') ||
      // Input bar rendered
      txt.includes('What do you want') || txt.includes('Start creating') ||
      // Credits area (we'll hide it, but its presence means app is ready)
      txt.includes('Generating will use') ||
      // Any real interactive element
      !!document.querySelector('textarea, [role="textbox"], nav, [class*="sidebar"]')
    );
  }

  function check() {
    if (isFlowReady()) {
      callback();                      // app is ready → transform + reveal
    } else if (Date.now() - start < MAX_WAIT_MS) {
      requestAnimationFrame(check);    // not ready yet → check next frame
    } else {
      callback();                      // safety timeout → reveal anyway
    }
  }

  // Start polling immediately if DOM exists, else wait for DOMContentLoaded
  if (document.readyState !== 'loading') {
    requestAnimationFrame(check);
  } else {
    document.addEventListener('DOMContentLoaded',
      () => requestAnimationFrame(check), { once: true });
  }
}

/* ─────────────────────────────────────────────────────────
   REVEAL PAGE — removes flash preventer
───────────────────────────────────────────────────────── */
function revealPage() {
  clearTimeout(window.__flowxFPTimer);
  const fp = document.getElementById('flowx-fp');
  if (fp) fp.remove();
}

/* ─────────────────────────────────────────────────────────
   INJECT TOP BANNER
───────────────────────────────────────────────────────── */
function injectTopBanner() {
  if (document.getElementById('flowx-banner')) return;
  const banner = document.createElement('div');
  banner.id = 'flowx-banner';
  document.body.appendChild(banner);
}

/* ─────────────────────────────────────────────────────────
   INJECT WATERMARK
───────────────────────────────────────────────────────── */
function injectWatermark() {
  if (document.getElementById('flowx-watermark')) return;
  const wm = document.createElement('div');
  wm.id = 'flowx-watermark';
  wm.textContent = 'FlowX';
  document.body.appendChild(wm);
}

/* ─────────────────────────────────────────────────────────
   INJECT CONTACT ADMIN MODAL
───────────────────────────────────────────────────────── */
function injectModal() {
  if (document.getElementById('flowx-modal-overlay')) return;

  const overlay = document.createElement('div');
  overlay.id = 'flowx-modal-overlay';
  overlay.innerHTML = `
    <div id="flowx-modal" role="dialog" aria-modal="true" aria-labelledby="flowx-modal-title">
      <button id="flowx-modal-close" aria-label="Close">✕</button>
      <div id="flowx-modal-logo">Flow<span>X</span></div>
      <div id="flowx-modal-subtitle">Powered by FlowX Premium</div>
      <div id="flowx-modal-title">Need More Credits?</div>
      <div id="flowx-modal-message">
        To purchase credits or get help with your account,<br>
        contact your FlowX admin directly on WhatsApp.
      </div>
      <a id="flowx-modal-whatsapp"
         href="${FLOWX.whatsappLink}"
         target="_blank"
         rel="noopener noreferrer"
         aria-label="Contact Admin on WhatsApp">
        <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
        Chat on WhatsApp
      </a>
      <div id="flowx-modal-divider"><span>or</span></div>
      <div id="flowx-modal-info">
        Contact your admin to upgrade your FlowX plan<br>and get unlimited access to premium models.
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  // Close on overlay click
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });

  // Close button
  document.getElementById('flowx-modal-close').addEventListener('click', closeModal);

  // Close on Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });
}

function openModal() {
  const overlay = document.getElementById('flowx-modal-overlay');
  if (overlay) {
    overlay.classList.add('flowx-open');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal() {
  const overlay = document.getElementById('flowx-modal-overlay');
  if (overlay) {
    overlay.classList.remove('flowx-open');
    document.body.style.overflow = '';
  }
}

/* ─────────────────────────────────────────────────────────
   CREATE CONTACT ADMIN BUTTON
───────────────────────────────────────────────────────── */
function createContactAdminBtn() {
  const btn = document.createElement('button');
  btn.id = 'flowx-contact-admin';
  btn.setAttribute('aria-label', 'Contact Admin for credits');
  btn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
    </svg>
    Contact Admin
  `;
  btn.addEventListener('click', openModal);
  return btn;
}

/* ─────────────────────────────────────────────────────────
   HIDE CREDITS AREA — completely removes from UI
   No replacement button is injected here.
   The entire row containing credits text is hidden so that
   no partial text, SVG icon, or spacing remnant is left.
───────────────────────────────────────────────────────── */
const hiddenCreditsElements = new WeakSet();

function processCreditsInNode(root) {
  // First: remove any previously-injected Contact Admin buttons
  // (they were added by an older version and cause the svg+text issue)
  root.querySelectorAll && root.querySelectorAll('#flowx-contact-admin').forEach(btn => {
    const inModal = btn.closest('#flowx-modal-overlay');
    if (!inModal) btn.remove();
  });

  // Walk text nodes looking for credits patterns
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
  const found = [];
  let node;
  while ((node = walker.nextNode())) {
    for (const pattern of CREDITS_TEXT_PATTERNS) {
      if (pattern.test(node.textContent)) { found.push(node); break; }
    }
  }

  for (const textNode of found) {
    // Walk UP the DOM to find the full row container.
    // We go up until we reach an element whose parent has multiple children
    // (indicating it's a layout row/flex container), max 8 levels.
    let container = textNode.parentElement;
    for (let i = 0; i < 8; i++) {
      if (!container || container === document.body) break;
      // Also accept a known credit-specific selector
      if (container.matches('[class*="credit"],[data-testid*="credit"]')) break;
      const parent = container.parentElement;
      if (!parent || parent === document.body) break;
      // Stop when parent has 2+ children — we're at the row level
      if (parent.children.length >= 2) break;
      container = parent;
    }

    if (!container || hiddenCreditsElements.has(container)) continue;
    hiddenCreditsElements.add(container);
    container.style.setProperty('display', 'none', 'important');
    container.setAttribute('data-flowx-credits-hidden', '1');
  }
}


/* ─────────────────────────────────────────────────────────
   TEXT NODE REPLACEMENT
   Uses WeakMap so we detect when React resets our changes.
───────────────────────────────────────────────────────── */
function replaceTextInNode(textNode) {
  const current = textNode.textContent;
  if (!current.trim()) return;

  // If we already set this exact value → no change needed, skip
  const lastSetValue = processedTextNodes.get(textNode);
  if (lastSetValue !== undefined && lastSetValue === current) return;

  let updated = current;
  for (const rule of TEXT_RULES) {
    updated = updated.replace(rule.pattern, rule.replacement);
  }

  if (updated !== current) {
    textNode.textContent = updated;
    processedTextNodes.set(textNode, updated); // remember what WE set it to
  }
}

/* ─────────────────────────────────────────────────────────
   INTERVAL SWEEP — Backup for stubborn React nodes
   Runs every 1 second to catch elements React keeps resetting
   (PRO badge, bottom-bar model selector, etc.)
───────────────────────────────────────────────────────── */
function startIntervalSweep() {
  setInterval(() => {
    if (!FLOWX.enabled) return;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const p = node.parentElement;
          if (!p) return NodeFilter.FILTER_REJECT;
          const t = p.tagName;
          if (t === 'SCRIPT' || t === 'STYLE') return NodeFilter.FILTER_REJECT;
          // Only check nodes that still have un-replaced content
          const txt = node.textContent;
          if (!txt.trim()) return NodeFilter.FILTER_SKIP;
          const needsWork = /\bPRO\b/.test(txt)
            || /Veo\s*3\.1\s*-\s*Lite/.test(txt)
            || /Veo\s*3\.1\s*-\s*Fast/.test(txt)
            || /\b270p\b/.test(txt)
            || /\b720p\b/.test(txt)
            || /\b1080p\b/.test(txt)
            || /\b1K\b/.test(txt);
          // NOTE: /\b2K\b/ intentionally OMITTED here.
          // "2K" is the output of our 1K→2K rename. If we include it,
          // the sweep finds renamed "2K" nodes and re-applies 2K→4K,
          // making both options show "4K". Original "2K" download labels
          // are ephemeral (popup menu) — MutationObserver handles them
          // the instant the menu opens. No interval sweep needed.
          return needsWork ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
        }
      }
    );

    let node;
    while ((node = walker.nextNode())) {
      // Force re-process: clear our stored value so replaceTextInNode runs
      processedTextNodes.delete(node);
      replaceTextInNode(node);
    }

    // Re-run hide functions + model name scan (submenus / panels may have re-rendered)
    hideQualityModel(document.body);
    hide4KUpgrade(document.body);
    hideDownloadSubtext(document.body);
    processModelNamesElementLevel(document.body);
  }, 1000);
}

function processTextReplacements(root) {
  // Skip our own injected elements
  const SKIP_IDS = ['flowx-banner', 'flowx-watermark', 'flowx-modal-overlay', 'flowx-contact-admin'];

  const walker = document.createTreeWalker(
    root,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        // Skip script/style
        const tag = parent.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') {
          return NodeFilter.FILTER_REJECT;
        }
        // Skip our own elements
        let el = parent;
        while (el) {
          if (SKIP_IDS.includes(el.id)) return NodeFilter.FILTER_REJECT;
          el = el.parentElement;
        }
        // Only process non-empty text
        if (!node.textContent.trim()) return NodeFilter.FILTER_SKIP;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  let node;
  while ((node = walker.nextNode())) {
    replaceTextInNode(node);
  }
}

/* ─────────────────────────────────────────────────────────
   ENHANCE → GENERATE BUTTON
───────────────────────────────────────────────────────── */
const enhancedButtons = new WeakSet();

function enhanceNextButtons(root) {
  // Target the arrow/send button in the bottom bar
  // Flow uses an SVG arrow button — we target by aria-label or position
  const candidates = root.querySelectorAll ? root.querySelectorAll([
    'button[aria-label*="Generate"]',
    'button[aria-label*="generate"]',
    'button[aria-label*="Create"]',
    'button[aria-label*="Send"]',
    'button[aria-label*="Next"]',
    'button[aria-label*="submit"]',
    // Target button containing only an SVG arrow (the → button in bottom bar)
    'form button:last-child',
  ].join(', ')) : [];

  for (const btn of candidates) {
    if (enhancedButtons.has(btn)) continue;
    enhancedButtons.add(btn);
    btn.classList.add('flowx-next-btn-enhanced');
  }
}

/* ─────────────────────────────────────────────────────────
   RUN ALL TRANSFORMATIONS
   ORDER IS CRITICAL:
   1. Hide original Quality model FIRST
   2. Rename text (Fast→Quality, Lite→Fast, PRO→ULTRA, 270p→Gif, etc.)
   3. Hide 4K Upgrade row
   4. Credits hiding
   5. Button enhancement
───────────────────────────────────────────────────────── */
function runTransformations() {
  hideQualityModel(document.body);
  processTextReplacements(document.body);
  processModelNamesElementLevel(document.body); // catches split-element Video Info
  hide4KUpgrade(document.body);
  hideDownloadSubtext(document.body);
  processCreditsInNode(document.body);
  enhanceNextButtons(document.body);
  disableProfileAvatar();
}

/* ─────────────────────────────────────────────────────────
   ELEMENT-LEVEL MODEL NAME PROCESSOR
   Scans leaf DOM elements by their full textContent, not just text nodes.
   This handles the Video Info case where React may render the model name
   split across child elements:
     <span>Veo 3.1 - </span><span>Lite</span>
   In that case text-node walkers never see "Veo 3.1 - Lite" as one string,
   but the leaf <span>Lite</span> has textContent === "Lite" which we can
   map using MODEL_TIER_MAP.
   Uses a centralized map that mirrors TEXT_RULES model renaming.
───────────────────────────────────────────────────────── */

// Central model-name map — single source of truth for all renames.
// Order: longest/most-specific patterns first to avoid partial matches.
const MODEL_RENAME_RULES = [
  // Full display-name forms (exact and flexible-dash)
  { re: /^Veo\s+3\.1\s*[-–—]\s*Fast$/i, out: 'veo 3.1 - Quality' },
  { re: /^Veo\s+3\.1\s*[-–—]\s*Lite$/i, out: 'veo 3.1 - Fast' },
  // API-format identifiers
  { re: /^veo-3\.1-flash$/i, out: 'veo 3.1 - Quality' },
  { re: /^veo-3\.1-fast$/i, out: 'veo 3.1 - Quality' },
  { re: /^veo-3\.1-lite$/i, out: 'veo 3.1 - Fast' },
  // Standalone tier labels (last resort — only when the ENTIRE element text is just the tier word)
  // Safe because we check for exact/whole-element match (^...$)
  { re: /^Fast$/, out: 'Quality' },
  { re: /^Lite$/, out: 'Fast' },
];

// Track which text nodes we already renamed via element-level scan
const processedModelTextNodes = new WeakSet();

function processModelNamesElementLevel(root) {
  if (!root || !root.querySelectorAll) return;
  const SKIP_IDS = ['flowx-banner', 'flowx-watermark', 'flowx-modal-overlay'];

  // querySelectorAll('*') visits every element. We look at leaf elements
  // (no child elements) so we compare full textContent to our patterns.
  const elements = root.querySelectorAll('*');

  for (const el of elements) {
    // Skip our own injected elements
    if (SKIP_IDS.includes(el.id)) continue;
    if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') continue;
    // Only process leaf elements (no child ELEMENTS, may have text nodes)
    if (el.children.length > 0) continue;

    const txt = el.textContent.trim();
    if (!txt) continue;

    for (const rule of MODEL_RENAME_RULES) {
      if (!rule.re.test(txt)) continue;

      // Found a match — replace the text in each child text node
      let changed = false;
      for (const child of el.childNodes) {
        if (child.nodeType !== Node.TEXT_NODE) continue;
        if (processedModelTextNodes.has(child)) continue;
        const newTxt = child.textContent.replace(rule.re, rule.out);
        if (newTxt !== child.textContent) {
          child.textContent = newTxt;
          processedModelTextNodes.add(child);
          changed = true;
        }
      }
      if (changed) break; // stop after first matching rule
    }
  }
}

/* ─────────────────────────────────────────────────────────
   HIDE 4K UPGRADE ROW
   Hides the '4K / Upgrade' option from the download submenu.
   Strategy: find text nodes containing 'Upgrade', walk up to
   confirm the container also has '4K' (uppercase K — our renamed
   '4k' lowercase is safe), then hide the full row element.
   Runs AFTER text replacement so '1080p→4k' is done first and
   the remaining '4K' is exclusively the Upgrade row.
───────────────────────────────────────────────────────── */
const hidden4KElements = new WeakSet();

function hide4KUpgrade(root) {
  if (!root) return;
  const walker = document.createTreeWalker(
    root, NodeFilter.SHOW_TEXT,
    {
      acceptNode(n) {
        const p = n.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        if (p.tagName === 'SCRIPT' || p.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
        if (n.id && n.id.startsWith('flowx')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  let node;
  while ((node = walker.nextNode())) {
    // Only match 'Upgrade' as a standalone word (the download Upgrade button)
    if (!/^\s*Upgrade\s*$/.test(node.textContent)) continue;

    // Confirm this 'Upgrade' is inside a '4K' context (uppercase K)
    let container = node.parentElement;
    let is4KContext = false;
    for (let i = 0; i < 8; i++) {
      if (!container || container === document.body) break;
      // Look for uppercase '4K' (our renamed 1080p is lowercase '4k', safe)
      if (/\b4K\b/.test(container.textContent)) { is4KContext = true; break; }
      container = container.parentElement;
    }
    if (!is4KContext || !container) continue;

    // Find the full row element to hide (walk up to a list-item-level element)
    let hideEl = container;
    for (let i = 0; i < 5; i++) {
      const parent = hideEl.parentElement;
      if (!parent || parent === document.body) break;
      if (parent.children.length >= 2) break; // we're at the list-item level
      hideEl = parent;
    }

    if (hidden4KElements.has(hideEl)) continue;
    hidden4KElements.add(hideEl);
    hideEl.style.setProperty('display', 'none', 'important');
    hideEl.setAttribute('data-flowx-4kupgrade-hidden', '1');
  }
}

/* ─────────────────────────────────────────────────────────
   HIDE DOWNLOAD SUBTEXT
   Removes the descriptive subtitle under each download option
   ("Animated GIF", "Original size", "Unedited") without
   affecting the option labels or download functionality.
───────────────────────────────────────────────────────── */
const DOWNLOAD_SUBTEXTS = [
  /^Animated\s+GIF$/i,
  /^Original\s+size$/i,
  /^Unedited$/i,
];
const hiddenSubtextElements = new WeakSet();

function hideDownloadSubtext(root) {
  if (!root) return;
  const walker = document.createTreeWalker(
    root, NodeFilter.SHOW_TEXT,
    {
      acceptNode(n) {
        const p = n.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        if (p.tagName === 'SCRIPT' || p.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  let node;
  while ((node = walker.nextNode())) {
    const txt = node.textContent.trim();
    if (!DOWNLOAD_SUBTEXTS.some(re => re.test(txt))) continue;

    // Hide the immediate parent element (the subtitle span/p/div)
    const el = node.parentElement;
    if (!el || hiddenSubtextElements.has(el)) continue;
    hiddenSubtextElements.add(el);
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('data-flowx-subtext-hidden', '1');
  }
}

/* ─────────────────────────────────────────────────────────
   DISABLE PROFILE AVATAR — NUCLEAR APPROACH
   Google Flow uses event delegation on parent containers,
   so blocking the button element alone is not enough.
   Three-layer strategy:
   1. Document-level capture interceptor (beats delegation)
   2. CSS pointer-events on img + all parents up to 10 levels
   3. Account panel killer (closes panel if it somehow opens)
───────────────────────────────────────────────────────── */

// ── Is the click target inside the avatar area? ──
function isInsideAvatarArea(target) {
  if (!target || target === document.body) return false;
  const imgs = document.querySelectorAll(
    'img[src*="googleusercontent"], img[src*="ggpht"], img[referrerpolicy="no-referrer"]'
  );
  for (const img of imgs) {
    let container = img;
    for (let i = 0; i < 10; i++) {
      if (!container || container === document.body) break;
      const tag = container.tagName;
      const role = container.getAttribute ? (container.getAttribute('role') || '') : '';
      if (tag === 'BUTTON' || tag === 'A' || role === 'button') {
        if (container === target || container.contains(target)) return true;
        break;
      }
      container = container.parentElement;
    }
    if (img === target || img.contains(target)) return true;
  }
  return false;
}

// ── Layer 1: Document-level nuclear blocker (runs once) ──
function setupAvatarNuclearBlock() {
  if (window.__flowxAvatarNuclearActive) return;
  window.__flowxAvatarNuclearActive = true;
  const BLOCK_EVENTS = [
    'click', 'mousedown', 'mouseup',
    'pointerdown', 'pointerup',
    'touchstart', 'touchend', 'touchmove',
  ];
  BLOCK_EVENTS.forEach(evtName => {
    document.addEventListener(evtName, (e) => {
      if (!FLOWX.enabled) return;
      if (isInsideAvatarArea(e.target)) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
      }
    }, { capture: true, passive: false });
  });
}

// ── Layer 3: Kill the Google account panel if it opens ──
function setupAccountPanelKiller() {
  if (window.__flowxPanelKillerActive) return;
  window.__flowxPanelKillerActive = true;
  const SIGS = ['Switch account', 'Sign out of all accounts', 'Manage subscription', 'Google Flow credits', 'Visible watermarking'];
  const killPanels = () => {
    if (!FLOWX.enabled) return;
    document.querySelectorAll('body > *').forEach(child => {
      if (child.id && child.id.startsWith('flowx')) return;
      if (child.getAttribute('data-flowx-panel-killed')) return;
      const txt = child.innerText || '';
      if (SIGS.some(s => txt.includes(s))) {
        child.style.setProperty('display', 'none', 'important');
        child.setAttribute('data-flowx-panel-killed', '1');
      }
    });
    document.querySelectorAll('[class*="menu"],[class*="dropdown"],[class*="panel"],[class*="dialog"]').forEach(el => {
      if (el.id && el.id.startsWith('flowx')) return;
      if (el.getAttribute('data-flowx-panel-killed')) return;
      const txt = el.innerText || '';
      if (SIGS.some(s => txt.includes(s))) {
        el.style.setProperty('display', 'none', 'important');
        el.setAttribute('data-flowx-panel-killed', '1');
      }
    });
  };
  const obs = new MutationObserver(killPanels);
  obs.observe(document.body, { childList: true, subtree: true });
}

// ── Layer 2: CSS pointer-events on img and ancestors ──
const disabledAvatarElements = new WeakSet();

function disableProfileAvatar() {
  // Layer 1 + 3: setup document blocker and panel killer (each once)
  setupAvatarNuclearBlock();
  setupAccountPanelKiller();

  // Layer 2: Apply pointer-events:none from img up through ALL ancestors
  const imgs = document.querySelectorAll(
    'img[src*="googleusercontent"], img[src*="ggpht"], img[referrerpolicy="no-referrer"]'
  );

  imgs.forEach(img => {
    let el = img;
    for (let i = 0; i < 10; i++) {
      if (!el || el === document.body) break;
      if (!disabledAvatarElements.has(el)) {
        disabledAvatarElements.add(el);
        el.style.setProperty('pointer-events', 'none', 'important');
        el.style.setProperty('cursor', 'default', 'important');
        el.setAttribute('data-flowx-avatar-blocked', '1');
      }
      const tag = el.tagName;
      const role = el.getAttribute ? (el.getAttribute('role') || '') : '';
      if (tag === 'BUTTON' || tag === 'A' || role === 'button') break; // stop here
      el = el.parentElement;
    }
  });
}

/* ─────────────────────────────────────────────────────────
   MUTATION OBSERVER — Watch for SPA DOM changes
───────────────────────────────────────────────────────── */
let transformationTimer = null;

function startObserver() {
  const observer = new MutationObserver((mutations) => {
    if (!FLOWX.enabled) return;

    // ── IMMEDIATE: hide Quality, 4K Upgrade, subtext + fix model names the instant they appear ──
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            hideQualityModel(node);
            hide4KUpgrade(node);
            hideDownloadSubtext(node);
            processModelNamesElementLevel(node); // Video Info model name fix
          }
        }
      }
    }

    // ── DEBOUNCED (80ms): all other transforms ──
    clearTimeout(transformationTimer);
    transformationTimer = setTimeout(() => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              processTextReplacements(node);
              processModelNamesElementLevel(node); // catch late React renders
              processCreditsInNode(node);
              enhanceNextButtons(node);
              disableProfileAvatar();       // re-check on DOM change
            } else if (node.nodeType === Node.TEXT_NODE) {
              replaceTextInNode(node);
            }
          }
        } else if (mutation.type === 'characterData') {
          if (mutation.target.nodeType === Node.TEXT_NODE) {
            replaceTextInNode(mutation.target);
          }
        }
      }
    }, 80);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
  });
}

/* ─────────────────────────────────────────────────────────
   SETTINGS UPDATE LISTENER (from popup)
───────────────────────────────────────────────────────── */
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SETTINGS_UPDATED') {
    FLOWX = { ...FLOWX, ...message.settings };

    if (!FLOWX.enabled) {
      // Remove FlowX injected elements
      ['flowx-banner', 'flowx-watermark', 'flowx-modal-overlay'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.remove();
      });
      // Restore hidden credits elements is complex; just reload
      // For now, just don't do further transforms
    } else {
      // Update WhatsApp link in modal
      const waLink = document.getElementById('flowx-modal-whatsapp');
      if (waLink) waLink.href = FLOWX.whatsappLink;
      runTransformations();
    }
  }
});

/* ─────────────────────────────────────────────────────────
   BOOTSTRAP
───────────────────────────────────────────────────────── */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadSettings);
} else {
  loadSettings();
}
