// FlowX Background Service Worker
'use strict';

// Default settings
const DEFAULT_SETTINGS = {
  enabled: true,
  whatsappNumber: '923001234567',
  whatsappLink: 'https://wa.me/923001234567',
  adminName: 'Admin',
};

// On install/update: set default settings + configure uninstall URL
chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const merged = { ...DEFAULT_SETTINGS, ...existing };
  await chrome.storage.local.set(merged);
  console.log('[FlowX] Extension installed. Settings initialized.');

  // Requirement 9 — When the extension is removed/uninstalled, Chrome
  // automatically opens this URL in a new tab so the user is logged out
  // of their Google account on the Flow website.
  chrome.runtime.setUninstallURL('https://accounts.google.com/Logout', () => {
    if (chrome.runtime.lastError) {
      console.warn('[FlowX] Could not set uninstall URL:', chrome.runtime.lastError);
    }
  });
});

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_SETTINGS') {
    chrome.storage.local.get(null).then(settings => {
      sendResponse({ success: true, settings });
    });
    return true; // async
  }

  if (message.type === 'SAVE_SETTINGS') {
    chrome.storage.local.set(message.settings).then(() => {
      sendResponse({ success: true });
      // Notify all flow.google.com tabs to refresh settings
      chrome.tabs.query({ url: '*://flow.google.com/*' }, tabs => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_UPDATED', settings: message.settings })
            .catch(() => {}); // ignore if tab has no content script
        });
      });
    });
    return true;
  }
});
