// FlowX Content Script — Auto-injects on flow.google.com
'use strict';

/* ─────────────────────────────────────────────────────────
   FLASH PREVENTER
   Hides the page IMMEDIATELY (before any React paint) so
   users never see the old/default UI during initialisation.
   revealPage() removes this once transforms are applied.
───────────────────────────────────────────────────────── */
; (function injectFlashPreventer() {
  try {
    const s = document.createElement('style');
    s.id = 'flowx-fp';
    // Hide the entire body; transitions disabled so no fade-in of old UI
    s.textContent = 'body{visibility:hidden!important;transition:none!important}';
    (document.head || document.documentElement).appendChild(s);
    // Safety valve: always reveal after 3 s even if init fails
    window.__flowxFPTimer = setTimeout(() => {
      const el = document.getElementById('flowx-fp');
      if (el) el.remove();
    }, 3000);
  } catch (_) { }
})();

/* ─────────────────────────────────────────────────────────
   CONFIG — Updated from storage
───────────────────────────────────────────────────────── */
let FLOWX = {
  enabled: true,
  whatsappNumber: '923001234567',
  whatsappLink: 'https://wa.me/923001234567',
  adminName: 'Admin',
};

// WeakMap: node → the value WE set it to last.
// Using WeakMap (not WeakSet) so we can detect when React resets the text
// back to the original and re-apply our replacement.
const processedTextNodes = new WeakMap();


/* ---------------------------------------------------------
   TEXT REPLACEMENT MAP
   CRITICAL ORDER:
   1. Full model-name patterns (catches model selector, Video Info full strings)
   2. PRO -> ULTRA badge
   3. Button renames
   4. Download resolution labels
   NOTE: processModelNamesElementLevel() handles split-element Video Info cases.
--------------------------------------------------------- */
const TEXT_RULES = [
  // -- [Lower Priority] model rename -- MOST SPECIFIC, must come FIRST --
  // This is the ONLY model that stays visible. Rename it to "veo 3.1 - Lite and Fast".
  { pattern: /Veo\s+3\.1\s*[-\u2013\u2014]\s*Lite\s*\[Lower\s*Priority\]/gi, replacement: 'veo 3.1 - Lite and Fast' },
  { pattern: /veo\s+3\.1\s*[-\u2013\u2014]\s*Lite\s*\[Lower\s*Priority\]/gi, replacement: 'veo 3.1 - Lite and Fast' },
  // -- PRO badge -> ULTRA --
  { pattern: /\bPRO\b/g, replacement: 'ULTRA' },
  // -- Button text --
  { pattern: /\bGenerate Video\b/gi, replacement: 'Create' },
  { pattern: /\bStart Creating\b/gi, replacement: 'New Project' },
  // -- Download resolution labels (video) --
  // NOTE: lowercase 'k' so these don't clash with uppercase '4K' Upgrade row.
  { pattern: /\b270p\b/g, replacement: 'Gif' },
  { pattern: /\b720p\b/g, replacement: '1k' },
  { pattern: /\b1080p\b/g, replacement: '4k' },
  // -- Image download labels --
  // ORDER IS CRITICAL: 2K->4K must come BEFORE 1K->2K to prevent chain-rename.
  { pattern: /\b2K\b/g, replacement: '4K' },
  { pattern: /\b1K\b/g, replacement: '2K' },
];

/* ---------------------------------------------------------
   MODEL HIDING + LOCKING SYSTEM
   KEEPS:  "veo 3.1 - Lite and Fast" (the Lower Priority model)
   HIDES:  ALL other models (Omni, Veo 3.1 Lite, Fast, Quality, etc.)
   LOCKS:  model selector so user cannot open the dropdown
   AUTO-SELECTS: "veo 3.1 - Lite and Fast" as default
   COLLAPSES: empty container left after hiding other models
--------------------------------------------------------- */
const hiddenModelItems = new WeakSet();

const MODEL_NAME_PATTERNS = [
  /Omni\s+\d/i,
  /Veo\s+3\.1\s*[-\u2013\u2014]\s*\w+/i,
  /veo\s+3\.1\s*[-\u2013\u2014]\s*\w+/i,
  /\bveo-3\.1-\w+/i,
];

function shouldHideModelText(txt) {
  if (!txt) return false;
  const lower = txt.toLowerCase();
  if (lower.includes('lower priority')) return false;
  if (lower.includes('lite and fast')) return false;
  return MODEL_NAME_PATTERNS.some(p => p.test(txt));
}

function findModelListItem(el) {
  let container = el;
  for (let i = 0; i < 8; i++) {
    if (!container || container === document.body) break;
    const role = container.getAttribute('role') || '';
    const tag = container.tagName;
    if (tag === 'LI' || role === 'option' || role === 'menuitem' || role === 'listitem') return container;
    const parent = container.parentElement;
    if (parent && parent !== document.body) {
      const sibs = Array.from(parent.children);
      if (sibs.length >= 3 && sibs.every(s => s.tagName === container.tagName) && container.tagName !== 'SPAN') {
        return container;
      }
    }
    container = container.parentElement;
  }
  return el;
}

function hideModelEl(el) {
  if (!el || hiddenModelItems.has(el) || el === document.body) return;
  const fullText = (el.textContent || '').toLowerCase();
  if (fullText.includes('lower priority') || fullText.includes('lite and fast')) return;
  hiddenModelItems.add(el);
  el.setAttribute('data-flowx-item-hidden', '1');
  el.style.setProperty('display', 'none', 'important');
}

/* Returns true if `el` is a descendant of an open model dropdown container
   (listbox / radiogroup / menu). Used to ensure we only hide dropdown LIST
   ITEMS, never the always-visible selector trigger button in the panel. */
function isInsideModelDropdown(el) {
  let p = el;
  let depth = 0;
  while (p && p !== document.body && depth < 15) {
    const role = (p.getAttribute('role') || '').toLowerCase();
    if (role === 'listbox' || role === 'radiogroup' || role === 'menu' || role === 'menubar') return true;
    p = p.parentElement;
    depth++;
  }
  return false;
}

function hideModelAreaCompletely(root) {
  if (!root) root = document.body;
  if (!root.querySelectorAll) return;

  // Inject CSS once to collapse hidden items and empty containers
  if (!document.getElementById('flowx-model-hide-css')) {
    const s = document.createElement('style');
    s.id = 'flowx-model-hide-css';
    s.textContent = [
      '[data-flowx-item-hidden]{display:none!important;height:0!important;overflow:hidden!important;padding:0!important;margin:0!important}',
      '[data-flowx-menu-collapsed]{display:none!important;height:0!important;overflow:hidden!important;padding:0!important;margin:0!important;border:none!important;box-shadow:none!important;background:none!important}',
      '[data-flowx-model-locked]{cursor:default!important;pointer-events:none!important;user-select:none!important}',
      '[data-flowx-model-locked] svg{display:none!important}',
    ].join('');
    (document.head || document.documentElement).appendChild(s);
  }

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const p = node.parentElement;
      if (!p) return NodeFilter.FILTER_REJECT;
      const tag = p.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE') return NodeFilter.FILTER_REJECT;
      if (!node.textContent.trim()) return NodeFilter.FILTER_SKIP;
      return NodeFilter.FILTER_ACCEPT;
    }
  });

  let node;
  while ((node = walker.nextNode())) {
    const txt = node.textContent.trim();
    if (!txt) continue;
    const startEl = node.parentElement;
    if (!startEl) continue;

    // Hide "Generating will use X credits" label (applies everywhere)
    if (/Generating will use/i.test(txt)) {
      let creditsEl = startEl;
      for (let i = 0; i < 4; i++) {
        const parent = creditsEl.parentElement;
        if (!parent || parent === document.body) break;
        if (parent.children.length > 3) break;
        if (/Generating will use/i.test(parent.textContent || '')) creditsEl = parent;
        creditsEl = parent;
      }
      hideModelEl(creditsEl);
      continue;
    }

    // Hide unwanted model option rows — ONLY inside dropdown overlays.
    // The always-visible trigger button (panel row) must NEVER be touched here;
    // fixModelSelectorTrigger() handles that separately.
    if (shouldHideModelText(txt) && isInsideModelDropdown(startEl)) {
      hideModelEl(findModelListItem(startEl));
    }
  }
}

const collapsedMenuContainers = new WeakSet();

function collapseEmptyModelMenus() {
  const CANDIDATES = [
    '[role="listbox"]', '[role="menu"]', '[role="menubar"]',
    '[role="radiogroup"]', '[role="group"]',
    '[class*="dropdown"]', '[class*="popover"]', '[class*="menu"]',
    '[class*="picker"]', '[class*="selector"]', '[class*="model"]',
  ];

  for (const container of document.querySelectorAll(CANDIDATES.join(','))) {
    if (container.id && container.id.startsWith('flowx')) continue;
    if (collapsedMenuContainers.has(container)) continue;
    if (container === document.body) continue;

    const children = Array.from(container.children);
    if (children.length === 0) continue;

    const fullText = (container.textContent || '').toLowerCase();
    // Never collapse if kept model is present or if it's a native context menu
    if (fullText.includes('lower priority') || fullText.includes('lite and fast')) continue;
    if (fullText.includes('download') || fullText.includes('favorite') || fullText.includes('rename')) continue;

    const allHidden = children.every(child => {
      if (child.getAttribute('data-flowx-item-hidden')) return true;
      const style = window.getComputedStyle(child);
      return style.display === 'none' || style.visibility === 'hidden';
    });

    if (allHidden && children.length > 0) {
      collapsedMenuContainers.add(container);
      container.setAttribute('data-flowx-menu-collapsed', '1');
      container.style.setProperty('display', 'none', 'important');
    }
  }

  // Also collapse by structure: containers where ALL children are hidden by us
  for (const el of document.querySelectorAll('body > * *')) {
    if (el.id && el.id.startsWith('flowx')) continue;
    if (collapsedMenuContainers.has(el)) continue;
    if (el === document.body) continue;
    const children = Array.from(el.children);
    if (children.length < 2 || children.length > 10) continue;
    if (!children.every(c => c.getAttribute('data-flowx-item-hidden') === '1')) continue;
    const txt = (el.textContent || '').toLowerCase();
    if (txt.includes('lower priority') || txt.includes('lite and fast')) continue;
    collapsedMenuContainers.add(el);
    el.setAttribute('data-flowx-menu-collapsed', '1');
    el.style.setProperty('display', 'none', 'important');
  }
}

// Lock model selector: prevent opening dropdown while keeping other controls usable
const lockedModelSelectors = new WeakSet();

const MODEL_SELECTOR_EXCLUSIONS = [
  'video', 'image', 'frames', 'ingredients',
  '16:9', '9:16', '4s', '6s', '8s', 'x1', 'x2', 'x3', 'x4',
  'generate', 'create', 'prompt',
];

function setupModelSelectorBlocker() {
  if (window.__flowxModelLockActive) return;
  window.__flowxModelLockActive = true;
  const BLOCK_EVENTS = [
    'click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup',
    'touchstart', 'touchend', 'keydown', 'keyup', 'keypress',
  ];
  for (const evtName of BLOCK_EVENTS) {
    document.addEventListener(evtName, (e) => {
      if (!FLOWX.enabled) return;
      let el = e.target;
      for (let i = 0; i < 3; i++) {
        if (!el || el === document.body) break;
        if (el.getAttribute('data-flowx-model-locked') === '1') {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          return;
        }
        el = el.parentElement;
      }
    }, { capture: true, passive: false });
  }
}

function lockModelSelector() {
  setupModelSelectorBlocker();
  const candidates = document.querySelectorAll(
    'button, [role="button"], [role="combobox"], [role="option"]'
  );
  for (const el of candidates) {
    if (el.id && el.id.startsWith('flowx')) continue;
    if (lockedModelSelectors.has(el)) continue;
    if (el === document.body) continue;
    const txt = (el.textContent || '').trim().toLowerCase();
    if (!txt.includes('lite and fast') && !txt.includes('lower priority')) continue;
    if (MODEL_SELECTOR_EXCLUSIONS.some(w => txt.includes(w))) continue;
    if (txt.length > 80) continue;
    lockedModelSelectors.add(el);
    el.setAttribute('data-flowx-model-locked', '1');
    el.style.setProperty('cursor', 'default', 'important');
    el.style.setProperty('pointer-events', 'none', 'important');
    el.style.setProperty('user-select', 'none', 'important');
    el.querySelectorAll('svg').forEach(svg => svg.style.setProperty('display', 'none', 'important'));
  }
}

/* ---------------------------------------------------------
   FIX MODEL SELECTOR TRIGGER
   Finds the always-visible model selector button/row in the
   video panel (NOT a dropdown list item), writes
   "veo 3.1 - Lite and Fast" into its text, and locks it so
   clicking cannot open the model dropdown.
   This makes the panel row ALWAYS show the correct model
   name regardless of what Flow has internally selected.
--------------------------------------------------------- */
const fixedTriggerElements = new WeakSet();

function fixModelSelectorTrigger() {
  // Candidates: buttons / comboboxes that are NOT inside a dropdown
  const candidates = document.querySelectorAll(
    'button, [role="button"], [role="combobox"]'
  );

  for (const el of candidates) {
    if (el.id && el.id.startsWith('flowx')) continue;
    if (el === document.body) continue;
    // Skip if inside a dropdown overlay
    if (isInsideModelDropdown(el)) continue;

    const txt = (el.textContent || '').trim();
    // Must contain a model name (or already our renamed value)
    const hasModel = MODEL_NAME_PATTERNS.some(p => p.test(txt)) ||
      /lite and fast/i.test(txt) ||
      /lower priority/i.test(txt);
    if (!hasModel) continue;
    // Skip panel wrappers (too long or contain unrelated controls)
    if (txt.length > 100) continue;
    const lower = txt.toLowerCase();
    const EXCLUSIONS = ['video', 'image', 'frames', 'ingredients',
      '16:9', '9:16', '4s', '6s', '8s', 'x1', 'x2', 'x3', 'x4',
      'generate', 'create', 'prompt', 'agent'];
    if (EXCLUSIONS.some(w => lower.includes(w))) continue;

    // Write "veo 3.1 - Lite and Fast" into the first model-name text node
    const tw = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let tNode;
    while ((tNode = tw.nextNode())) {
      const t = tNode.textContent.trim();
      if (!t) continue;
      if (MODEL_NAME_PATTERNS.some(p => p.test(t)) ||
        /lite and fast/i.test(t) || /lower priority/i.test(t)) {
        if (tNode.textContent !== 'veo 3.1 - Lite and Fast') {
          tNode.textContent = 'veo 3.1 - Lite and Fast';
        }
        break;
      }
    }

    // Lock: prevent opening the dropdown
    if (!fixedTriggerElements.has(el)) {
      fixedTriggerElements.add(el);
      el.setAttribute('data-flowx-model-locked', '1');
      el.style.setProperty('pointer-events', 'none', 'important');
      el.style.setProperty('cursor', 'default', 'important');
      el.querySelectorAll('svg').forEach(svg =>
        svg.style.setProperty('display', 'none', 'important')
      );
    }
  }
}


let autoSelectAttempts = 0;
const MAX_AUTO_SELECT_ATTEMPTS = 20;

function autoSelectOnlyModel() {
  if (autoSelectAttempts >= MAX_AUTO_SELECT_ATTEMPTS) return;
  autoSelectAttempts++;
  const candidates = document.querySelectorAll(
    '[role="option"], [role="menuitem"], [role="radio"], [role="button"], li, button'
  );
  for (const el of candidates) {
    if (el.id && el.id.startsWith('flowx')) continue;
    const txt = (el.textContent || '').toLowerCase();
    if (!txt.includes('lite and fast') && !txt.includes('lower priority')) continue;
    if (el.getAttribute('aria-selected') === 'true') {
      autoSelectAttempts = MAX_AUTO_SELECT_ATTEMPTS;
      return;
    }
    try { el.click(); } catch (_) { }
    try { el.setAttribute('aria-selected', 'true'); } catch (_) { }
    return;
  }
}


/* ─────────────────────────────────────────────────────────
   SELECTORS — Elements to watch / modify
───────────────────────────────────────────────────────── */
// Selectors for the "credits" pill / text (the one showing "X credits")
const CREDITS_SELECTORS = [
  '[data-testid*="credit"]',
  '[class*="credit"]',
  '[aria-label*="credit"]',
  'button[aria-label*="credit"]',
];

// Text patterns that indicate a credits display
const CREDITS_TEXT_PATTERNS = [
  /Generating will use \d+ credits/i,
  /\d+ credits? remaining/i,
  /\d+ credits?/i,
  /credits? balance/i,
];

/* ─────────────────────────────────────────────────────────
   LOAD SETTINGS
───────────────────────────────────────────────────────── */
function loadSettings() {
  chrome.storage.local.get(null, (settings) => {
    if (settings) {
      FLOWX = { ...FLOWX, ...settings };
    }
    if (FLOWX.enabled) {
      init();
    }
  });
}

/* ─────────────────────────────────────────────────────────
   INIT
───────────────────────────────────────────────────────── */
function init() {
  injectTopBanner();
  injectWatermark();
  injectModal();

  // Start heartbeat FIRST — so the page monitor sees it immediately.
  startHeartbeat();
  injectHeartbeatMonitor();

  // Start observer and interval EARLY — they catch React mutations
  // as the app renders, applying transforms on the fly.
  startObserver();
  startIntervalSweep();

  // DO NOT reveal immediately. Wait until Google Flow's React app has
  // actually rendered content, THEN transform + reveal.
  waitForAppReady(() => {
    runTransformations();
    // One rAF: let transforms paint before body becomes visible
    requestAnimationFrame(revealPage);
  });
}

/* ─────────────────────────────────────────────────────────
   WAIT FOR APP READY
   Polls via requestAnimationFrame until Google Flow's React
   app has rendered meaningful content (models, nav, input).
   Only then do we transform + reveal.

   This is the initialization gate the user requires:
     isInitializing=true  → body hidden, waiting
     React renders        → observer applies transforms live
     content detected     → runTransformations() + reveal
     isInitializing=false → page visible with correct UI
───────────────────────────────────────────────────────── */
function waitForAppReady(callback) {
  const MAX_WAIT_MS = 5000;
  const start = Date.now();

  // Signals that Google Flow has rendered its main UI:
  function isFlowReady() {
    if (!document.body) return false;
    const txt = document.body.textContent || '';
    return (
      // Model names present → React rendered the header/model selector
      txt.includes('Veo') || txt.includes('Omni') ||
      // Navigation sidebar rendered
      txt.includes('All media') || txt.includes('Characters') ||
      // Input bar rendered
      txt.includes('What do you want') || txt.includes('Start creating') ||
      // Credits area (we'll hide it, but its presence means app is ready)
      txt.includes('Generating will use') ||
      // Any real interactive element
      !!document.querySelector('textarea, [role="textbox"], nav, [class*="sidebar"]')
    );
  }

  function check() {
    if (isFlowReady()) {
      callback();                      // app is ready → transform + reveal
    } else if (Date.now() - start < MAX_WAIT_MS) {
      requestAnimationFrame(check);    // not ready yet → check next frame
    } else {
      callback();                      // safety timeout → reveal anyway
    }
  }

  // Start polling immediately if DOM exists, else wait for DOMContentLoaded
  if (document.readyState !== 'loading') {
    requestAnimationFrame(check);
  } else {
    document.addEventListener('DOMContentLoaded',
      () => requestAnimationFrame(check), { once: true });
  }
}

/* ─────────────────────────────────────────────────────────
   REVEAL PAGE — removes flash preventer
───────────────────────────────────────────────────────── */
function revealPage() {
  clearTimeout(window.__flowxFPTimer);
  const fp = document.getElementById('flowx-fp');
  if (fp) fp.remove();
}

/* ─────────────────────────────────────────────────────────
   INJECT TOP BANNER
───────────────────────────────────────────────────────── */
function injectTopBanner() {
  if (document.getElementById('flowx-banner')) return;
  const banner = document.createElement('div');
  banner.id = 'flowx-banner';
  document.body.appendChild(banner);
}

/* ─────────────────────────────────────────────────────────
   INJECT WATERMARK
───────────────────────────────────────────────────────── */
function injectWatermark() {
  if (document.getElementById('flowx-watermark')) return;
  const wm = document.createElement('div');
  wm.id = 'flowx-watermark';
  wm.textContent = 'FlowX';
  document.body.appendChild(wm);
}

/* ─────────────────────────────────────────────────────────
   INJECT CONTACT ADMIN MODAL
───────────────────────────────────────────────────────── */
function injectModal() {
  if (document.getElementById('flowx-modal-overlay')) return;

  const overlay = document.createElement('div');
  overlay.id = 'flowx-modal-overlay';
  overlay.innerHTML = `
    <div id="flowx-modal" role="dialog" aria-modal="true" aria-labelledby="flowx-modal-title">
      <button id="flowx-modal-close" aria-label="Close">✕</button>
      <div id="flowx-modal-logo">Flow<span>X</span></div>
      <div id="flowx-modal-subtitle">Powered by FlowX Premium</div>
      <div id="flowx-modal-title">Need More Credits?</div>
      <div id="flowx-modal-message">
        To purchase credits or get help with your account,<br>
        contact your FlowX admin directly on WhatsApp.
      </div>
      <a id="flowx-modal-whatsapp"
         href="${FLOWX.whatsappLink}"
         target="_blank"
         rel="noopener noreferrer"
         aria-label="Contact Admin on WhatsApp">
        <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
        Chat on WhatsApp
      </a>
      <div id="flowx-modal-divider"><span>or</span></div>
      <div id="flowx-modal-info">
        Contact your admin to upgrade your FlowX plan<br>and get unlimited access to premium models.
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  // Close on overlay click
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });

  // Close button
  document.getElementById('flowx-modal-close').addEventListener('click', closeModal);

  // Close on Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });
}

function openModal() {
  const overlay = document.getElementById('flowx-modal-overlay');
  if (overlay) {
    overlay.classList.add('flowx-open');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal() {
  const overlay = document.getElementById('flowx-modal-overlay');
  if (overlay) {
    overlay.classList.remove('flowx-open');
    document.body.style.overflow = '';
  }
}

/* ─────────────────────────────────────────────────────────
   CREATE CONTACT ADMIN BUTTON
───────────────────────────────────────────────────────── */
function createContactAdminBtn() {
  const btn = document.createElement('button');
  btn.id = 'flowx-contact-admin';
  btn.setAttribute('aria-label', 'Contact Admin for credits');
  btn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
    </svg>
    Contact Admin
  `;
  btn.addEventListener('click', openModal);
  return btn;
}

/* ─────────────────────────────────────────────────────────
   HIDE CREDITS AREA — completely removes from UI
   No replacement button is injected here.
   The entire row containing credits text is hidden so that
   no partial text, SVG icon, or spacing remnant is left.
───────────────────────────────────────────────────────── */
const hiddenCreditsElements = new WeakSet();

function processCreditsInNode(root) {
  // First: remove any previously-injected Contact Admin buttons
  // (they were added by an older version and cause the svg+text issue)
  root.querySelectorAll && root.querySelectorAll('#flowx-contact-admin').forEach(btn => {
    const inModal = btn.closest('#flowx-modal-overlay');
    if (!inModal) btn.remove();
  });

  // Walk text nodes looking for credits patterns
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
  const found = [];
  let node;
  while ((node = walker.nextNode())) {
    for (const pattern of CREDITS_TEXT_PATTERNS) {
      if (pattern.test(node.textContent)) { found.push(node); break; }
    }
  }

  for (const textNode of found) {
    // Walk UP the DOM to find the full row container.
    // We go up until we reach an element whose parent has multiple children
    // (indicating it's a layout row/flex container), max 8 levels.
    let container = textNode.parentElement;
    for (let i = 0; i < 8; i++) {
      if (!container || container === document.body) break;
      // Also accept a known credit-specific selector
      if (container.matches('[class*="credit"],[data-testid*="credit"]')) break;
      const parent = container.parentElement;
      if (!parent || parent === document.body) break;
      // Stop when parent has 2+ children — we're at the row level
      if (parent.children.length >= 2) break;
      container = parent;
    }

    if (!container || hiddenCreditsElements.has(container)) continue;
    hiddenCreditsElements.add(container);
    container.style.setProperty('display', 'none', 'important');
    container.setAttribute('data-flowx-credits-hidden', '1');
  }
}


/* ─────────────────────────────────────────────────────────
   TEXT NODE REPLACEMENT
   Uses WeakMap so we detect when React resets our changes.
───────────────────────────────────────────────────────── */
function replaceTextInNode(textNode) {
  const current = textNode.textContent;
  if (!current.trim()) return;

  // If we already set this exact value → no change needed, skip
  const lastSetValue = processedTextNodes.get(textNode);
  if (lastSetValue !== undefined && lastSetValue === current) return;

  let updated = current;
  for (const rule of TEXT_RULES) {
    updated = updated.replace(rule.pattern, rule.replacement);
  }

  if (updated !== current) {
    textNode.textContent = updated;
    processedTextNodes.set(textNode, updated); // remember what WE set it to
  }
}

/* ─────────────────────────────────────────────────────────
   INTERVAL SWEEP — Backup for stubborn React nodes
   Runs every 1 second to catch elements React keeps resetting
   (PRO badge, bottom-bar model selector, etc.)
───────────────────────────────────────────────────────── */
function startIntervalSweep() {
  setInterval(() => {
    if (!FLOWX.enabled) return;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const p = node.parentElement;
          if (!p) return NodeFilter.FILTER_REJECT;
          const t = p.tagName;
          if (t === 'SCRIPT' || t === 'STYLE') return NodeFilter.FILTER_REJECT;
          // Only check nodes that still have un-replaced content
          const txt = node.textContent;
          if (!txt.trim()) return NodeFilter.FILTER_SKIP;
          const needsWork = /\bPRO\b/.test(txt)
            || /Lower\s*Priority/i.test(txt)
            || /\b270p\b/.test(txt)
            || /\b720p\b/.test(txt)
            || /\b1080p\b/.test(txt)
            || /\b1K\b/.test(txt);
          // NOTE: /\b2K\b/ intentionally OMITTED here.
          // "2K" is the output of our 1K→2K rename. If we include it,
          // the sweep finds renamed "2K" nodes and re-applies 2K→4K,
          // making both options show "4K". Original "2K" download labels
          // are ephemeral (popup menu) — MutationObserver handles them
          // the instant the menu opens. No interval sweep needed.
          return needsWork ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
        }
      }
    );

    let node;
    while ((node = walker.nextNode())) {
      // Force re-process: clear our stored value so replaceTextInNode runs
      processedTextNodes.delete(node);
      replaceTextInNode(node);
    }

    // Re-run model hide + lock + other hide functions every sweep
    hideModelAreaCompletely(document.body);
    collapseEmptyModelMenus();
    fixModelSelectorTrigger();
    lockModelSelector();
    autoSelectOnlyModel();
    hide4KUpgrade(document.body);
    hideDownloadSubtext(document.body);
  }, 1000);
}

function processTextReplacements(root) {
  const SKIP_IDS = ['flowx-banner', 'flowx-watermark', 'flowx-modal-overlay', 'flowx-contact-admin'];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (!parent) return NodeFilter.FILTER_REJECT;
      const tag = parent.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
      let el = parent;
      while (el) {
        if (SKIP_IDS.includes(el.id)) return NodeFilter.FILTER_REJECT;
        el = el.parentElement;
      }
      if (!node.textContent.trim()) return NodeFilter.FILTER_SKIP;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  let node;
  while ((node = walker.nextNode())) { replaceTextInNode(node); }
}

/* ─────────────────────────────────────────────────────────
   ENHANCE → GENERATE BUTTON
───────────────────────────────────────────────────────── */
const enhancedButtons = new WeakSet();

function enhanceNextButtons(root) {
  const candidates = root.querySelectorAll ? root.querySelectorAll([
    'button[aria-label*="Generate"]', 'button[aria-label*="generate"]',
    'button[aria-label*="Create"]', 'button[aria-label*="Send"]',
    'button[aria-label*="Next"]', 'button[aria-label*="submit"]',
    'form button:last-child',
  ].join(', ')) : [];
  for (const btn of candidates) {
    if (enhancedButtons.has(btn)) continue;
    enhancedButtons.add(btn);
    btn.classList.add('flowx-next-btn-enhanced');
  }
}

/* ─────────────────────────────────────────────────────────
   RUN ALL TRANSFORMATIONS
───────────────────────────────────────────────────────── */
function runTransformations() {
  hideModelAreaCompletely(document.body);
  collapseEmptyModelMenus();
  fixModelSelectorTrigger();
  processTextReplacements(document.body);
  hide4KUpgrade(document.body);
  hideDownloadSubtext(document.body);
  processCreditsInNode(document.body);
  enhanceNextButtons(document.body);
  disableProfileAvatar();
  // Staggered lock + auto-select so React has time to render the selector
  setTimeout(() => { lockModelSelector(); autoSelectOnlyModel(); fixModelSelectorTrigger(); }, 300);
  setTimeout(() => { lockModelSelector(); autoSelectOnlyModel(); fixModelSelectorTrigger(); }, 800);
  setTimeout(() => { lockModelSelector(); autoSelectOnlyModel(); fixModelSelectorTrigger(); }, 1500);
  setTimeout(() => { fixModelSelectorTrigger(); }, 3000);
}



/* ─────────────────────────────────────────────────────────
   HIDE 4K UPSCALE CARD
   Hides the "4K / Upscaled · 50 credits" option from the
   download/upscale menu.

   STRATEGY:
   The unique identifier is "credits" text inside the card.
   No regular download option (Gif, 1k, 4k) mentions credits.
   We find text nodes containing "credit", walk up to the
   card/row container, and hide the entire card.
   We also hide the "Upscaled" section header label above it.

   SAFE: "Gif", "1k", "4k" options are never touched.
───────────────────────────────────────────────────────── */
const hidden4KElements = new WeakSet();

function hide4KUpgrade(root) {
  if (!root) return;
  const walker = document.createTreeWalker(
    root, NodeFilter.SHOW_TEXT,
    {
      acceptNode(n) {
        const p = n.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        if (p.tagName === 'SCRIPT' || p.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
        if (p.id && p.id.startsWith('flowx')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  let node;
  while ((node = walker.nextNode())) {
    const txt = node.textContent.trim();

    // ── Target 1: Find "credits" text (e.g. "Upscaled · 50 credits") ──
    // This is the subtitle inside the 4K upscale card.
    // No regular download option ever contains "credits".
    if (/credit/i.test(txt)) {
      // Walk up to find the card/row container
      let cardEl = node.parentElement;
      if (!cardEl) continue;
      for (let i = 0; i < 8; i++) {
        if (!cardEl || cardEl === document.body) break;
        const parent = cardEl.parentElement;
        if (!parent || parent === document.body) break;
        // Stop when we reach a container whose parent has 2+ children
        // (meaning we've found the card-level element in the list)
        if (parent.children.length >= 2) break;
        cardEl = parent;
      }

      // Safety: skip if this container also has Gif/1k/4k sibling text
      // (meaning we walked too far and grabbed the entire menu)
      const cardText = (cardEl.textContent || '').toLowerCase();
      if (cardText.includes('gif') && cardText.includes('1k')) continue;

      if (hidden4KElements.has(cardEl)) continue;
      hidden4KElements.add(cardEl);
      cardEl.style.setProperty('display', 'none', 'important');
      cardEl.setAttribute('data-flowx-4kupgrade-hidden', '1');
      continue;
    }

    // ── Target 2: Find standalone "Upscaled" section header ──
    // This is the grey "Upscaled" label above the 4K card.
    // Must be standalone text (not part of "4K Upscaled" combined label).
    if (/^Upscaled$/i.test(txt)) {
      // Walk up a few levels to find the header element
      let headerEl = node.parentElement;
      if (!headerEl) continue;
      for (let i = 0; i < 4; i++) {
        if (!headerEl || headerEl === document.body) break;
        const parent = headerEl.parentElement;
        if (!parent || parent === document.body) break;
        if (parent.children.length >= 2) break;
        headerEl = parent;
      }

      // Safety: don't hide if this is part of a larger label
      const elText = (headerEl.textContent || '').trim();
      if (elText.length > 20) continue; // too much text, skip

      if (hidden4KElements.has(headerEl)) continue;
      hidden4KElements.add(headerEl);
      headerEl.style.setProperty('display', 'none', 'important');
      headerEl.setAttribute('data-flowx-4kupgrade-hidden', '1');
    }

    // ── Target C: Standalone uppercase "4K" (CASE-SENSITIVE — no /i flag) ──
    // TEXT_RULES rename 1080p → "4k" (lowercase k) — that will never match here.
    // The upscale/upgrade option renders as "4K" (uppercase K) — this matches it.
    // Case is the only reliable differentiator when credits text is absent.
    if (txt === '4K') {
      // Walk up to find the row-level element.
      // Stop when parent has 2+ children = reached the list-item boundary.
      let rowEl = node.parentElement;
      if (!rowEl) continue;
      for (let i = 0; i < 8; i++) {
        if (!rowEl || rowEl === document.body) break;
        const parent = rowEl.parentElement;
        if (!parent || parent === document.body) break;
        if (parent.children.length >= 2) break;
        rowEl = parent;
      }

      // Safety: ensure we haven't walked too far and grabbed the whole menu.
      // If the container text includes lowercase '4k', 'gif', or '1k'
      // we went past the item boundary.
      const rowText = (rowEl.textContent || '').trim();
      if (/\b4k\b/.test(rowText)) continue;      // lowercase k = walked too far
      if (/\bgif\b/i.test(rowText)) continue;    // Gif present = whole menu
      if (/\b1k\b/i.test(rowText)) continue;     // 1k present = whole menu
      if (rowText.length > 30) continue;          // too long = not just the label

      if (hidden4KElements.has(rowEl)) continue;
      hidden4KElements.add(rowEl);
      rowEl.style.setProperty('display', 'none', 'important');
      rowEl.setAttribute('data-flowx-4kupgrade-hidden', '1');
    }
  }
}

/* ─────────────────────────────────────────────────────────
   HIDE DOWNLOAD SUBTEXT
   Removes the descriptive subtitle under each download option
   ("Animated GIF", "Original size", "Unedited") without
   affecting the option labels or download functionality.
───────────────────────────────────────────────────────── */
const DOWNLOAD_SUBTEXTS = [
  /^Animated\s+GIF$/i,
  /^Original\s+size$/i,
  /^Unedited$/i,
];
const hiddenSubtextElements = new WeakSet();

function hideDownloadSubtext(root) {
  if (!root) return;
  const walker = document.createTreeWalker(
    root, NodeFilter.SHOW_TEXT,
    {
      acceptNode(n) {
        const p = n.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        if (p.tagName === 'SCRIPT' || p.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  let node;
  while ((node = walker.nextNode())) {
    const txt = node.textContent.trim();
    if (!DOWNLOAD_SUBTEXTS.some(re => re.test(txt))) continue;

    // Hide the immediate parent element (the subtitle span/p/div)
    const el = node.parentElement;
    if (!el || hiddenSubtextElements.has(el)) continue;
    hiddenSubtextElements.add(el);
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('data-flowx-subtext-hidden', '1');
  }
}

/* ─────────────────────────────────────────────────────────
   DISABLE PROFILE AVATAR — NUCLEAR APPROACH
   Google Flow uses event delegation on parent containers,
   so blocking the button element alone is not enough.
   Three-layer strategy:
   1. Document-level capture interceptor (beats delegation)
   2. CSS pointer-events on img + all parents up to 10 levels
   3. Account panel killer (closes panel if it somehow opens)
───────────────────────────────────────────────────────── */

// ── Is the click target inside the avatar area? ──
function isInsideAvatarArea(target) {
  if (!target || target === document.body) return false;
  // Only match actual Google profile avatar images — NOT video thumbnails.
  // Removed img[referrerpolicy="no-referrer"] because Flow uses that attribute
  // on video thumbnails too, which caused the 3-dot menu to become unclickable.
  const imgs = document.querySelectorAll(
    'img[src*="googleusercontent"], img[src*="ggpht"]'
  );
  for (const img of imgs) {
    let container = img;
    for (let i = 0; i < 10; i++) {
      if (!container || container === document.body) break;
      const tag = container.tagName;
      const role = container.getAttribute ? (container.getAttribute('role') || '') : '';
      if (tag === 'BUTTON' || tag === 'A' || role === 'button') {
        if (container === target || container.contains(target)) return true;
        break;
      }
      container = container.parentElement;
    }
    if (img === target || img.contains(target)) return true;
  }
  return false;
}

// ── Layer 1: Document-level nuclear blocker (runs once) ──
function setupAvatarNuclearBlock() {
  if (window.__flowxAvatarNuclearActive) return;
  window.__flowxAvatarNuclearActive = true;
  const BLOCK_EVENTS = [
    'click', 'mousedown', 'mouseup',
    'pointerdown', 'pointerup',
    'touchstart', 'touchend', 'touchmove',
  ];
  BLOCK_EVENTS.forEach(evtName => {
    document.addEventListener(evtName, (e) => {
      if (!FLOWX.enabled) return;
      if (isInsideAvatarArea(e.target)) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
      }
    }, { capture: true, passive: false });
  });
}

// ── Layer 3: Kill the Google account panel if it opens ──
// IMPORTANT: Requires at least 2 account-specific signals to match.
// This prevents false positives on the Download submenu, which
// contains "Visible watermarking" text but is NOT the account panel.
function setupAccountPanelKiller() {
  if (window.__flowxPanelKillerActive) return;
  window.__flowxPanelKillerActive = true;
  const SIGS = ['Switch account', 'Sign out of all accounts', 'Manage subscription', 'Google Flow credits', 'Visible watermarking'];

  // Returns true only if the element's text matches at least 2 SIGS
  // AND does not contain download-related text.
  function shouldKill(txt) {
    if (!txt) return false;
    // Never kill elements that are part of the download menu
    if (txt.includes('Download')) return false;
    // Require at least 2 account-panel signatures to match
    let matchCount = 0;
    for (const s of SIGS) {
      if (txt.includes(s)) matchCount++;
      if (matchCount >= 2) return true;
    }
    return false;
  }

  const killPanels = () => {
    if (!FLOWX.enabled) return;
    document.querySelectorAll('body > *').forEach(child => {
      if (child.id && child.id.startsWith('flowx')) return;
      if (child.getAttribute('data-flowx-panel-killed')) return;
      const txt = child.innerText || '';
      if (shouldKill(txt)) {
        child.style.setProperty('display', 'none', 'important');
        child.setAttribute('data-flowx-panel-killed', '1');
      }
    });
    document.querySelectorAll('[class*="menu"],[class*="dropdown"],[class*="panel"],[class*="dialog"]').forEach(el => {
      if (el.id && el.id.startsWith('flowx')) return;
      if (el.getAttribute('data-flowx-panel-killed')) return;
      const txt = el.innerText || '';
      if (shouldKill(txt)) {
        el.style.setProperty('display', 'none', 'important');
        el.setAttribute('data-flowx-panel-killed', '1');
      }
    });
  };
  const obs = new MutationObserver(killPanels);
  obs.observe(document.body, { childList: true, subtree: true });
}

// ── Layer 2: CSS pointer-events on img and ancestors ──
const disabledAvatarElements = new WeakSet();

function disableProfileAvatar() {
  // Layer 1 + 3: setup document blocker and panel killer (each once)
  setupAvatarNuclearBlock();
  setupAccountPanelKiller();

  // Layer 2: Apply pointer-events:none from img up through ancestors.
  // Only match actual Google profile avatar images — NOT video thumbnails.
  // Removed img[referrerpolicy="no-referrer"] because Flow uses that attribute
  // on video thumbnails too, which applied pointer-events:none to the ancestor
  // containers that hold the 3-dot menu button, killing all interactivity.
  const imgs = document.querySelectorAll(
    'img[src*="googleusercontent"], img[src*="ggpht"]'
  );

  imgs.forEach(img => {
    let el = img;
    for (let i = 0; i < 10; i++) {
      if (!el || el === document.body) break;
      if (!disabledAvatarElements.has(el)) {
        disabledAvatarElements.add(el);
        el.style.setProperty('pointer-events', 'none', 'important');
        el.style.setProperty('cursor', 'default', 'important');
        el.setAttribute('data-flowx-avatar-blocked', '1');
      }
      const tag = el.tagName;
      const role = el.getAttribute ? (el.getAttribute('role') || '') : '';
      if (tag === 'BUTTON' || tag === 'A' || role === 'button') break; // stop here
      el = el.parentElement;
    }
  });
}

/* ─────────────────────────────────────────────────────────
   MUTATION OBSERVER — Watch for SPA DOM changes
───────────────────────────────────────────────────────── */
let transformationTimer = null;

function startObserver() {
  const observer = new MutationObserver((mutations) => {
    if (!FLOWX.enabled) return;

    // -- IMMEDIATE: hide models + 4K Upgrade + subtext the instant they appear --
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            hideModelAreaCompletely(node);
            hide4KUpgrade(node);
            hideDownloadSubtext(node);
          }
        }
      }
    }
    // Collapse shells + lock selector immediately after hiding model items
    collapseEmptyModelMenus();
    lockModelSelector();

    // ── DEBOUNCED (80ms): all other transforms ──
    clearTimeout(transformationTimer);
    transformationTimer = setTimeout(() => {
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              processTextReplacements(node);
              processCreditsInNode(node);
              enhanceNextButtons(node);
              disableProfileAvatar();       // re-check on DOM change
            } else if (node.nodeType === Node.TEXT_NODE) {
              replaceTextInNode(node);
            }
          }
        } else if (mutation.type === 'characterData') {
          if (mutation.target.nodeType === Node.TEXT_NODE) {
            replaceTextInNode(mutation.target);
          }
        }
      }
      // Re-run model hide + lock + trigger fix after React re-render
      collapseEmptyModelMenus();
      lockModelSelector();
      autoSelectOnlyModel();
      fixModelSelectorTrigger();
    }, 80);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
  });
}

/* ─────────────────────────────────────────────────────────
   HEARTBEAT PROTECTION SYSTEM
   Two layers:
   1. Content-script heartbeat — writes a timestamp to
      sessionStorage every 3 s while the extension is active.
   2. Page-injected IIFE monitor — runs in the page's own JS
      context (so it survives content-script death) and watches
      the timestamp. If it goes stale the extension is gone,
      so it triggers Google's native logout URL.
   Grace period: 15 s on every page load, so normal refresh
   and extension startup never trigger a false logout.
───────────────────────────────────────────────────────── */
const FLOWX_HB_KEY = 'flowx_heartbeat';
const FLOWX_HB_INTERVAL = 3000; // write every 3 s
let _hbInterval = null;

function writeHeartbeat() {
  try { sessionStorage.setItem(FLOWX_HB_KEY, Date.now().toString()); } catch (_) { }
}

function startHeartbeat() {
  writeHeartbeat();
  if (_hbInterval) clearInterval(_hbInterval);
  _hbInterval = setInterval(() => {
    if (FLOWX.enabled) writeHeartbeat();
    // If disabled, stop writing — the page monitor will detect the stale key.
  }, FLOWX_HB_INTERVAL);
}

function stopHeartbeat() {
  if (_hbInterval) { clearInterval(_hbInterval); _hbInterval = null; }
  try { sessionStorage.removeItem(FLOWX_HB_KEY); } catch (_) { }
}

// Trigger Google Flow's native logout via the standard accounts logout URL.
function triggerFlowLogout() {
  try {
    window.location.href = 'https://accounts.google.com/Logout?continue=' +
      encodeURIComponent('https://flow.google.com');
  } catch (_) { }
}

// Inject the monitor IIFE into the page's own JS context.
// This script keeps running even after the content script is destroyed
// (extension disabled/removed), so it can detect the dead heartbeat.
function injectHeartbeatMonitor() {
  if (document.getElementById('flowx-hb-monitor-tag')) return;

  const GRACE_MS = 15000; // ignore first 15 s after page load (let extension init)
  const TIMEOUT_MS = 12000; // 12 s stale heartbeat = extension is gone
  const CHECK_MS = 5000;  // check every 5 s
  const HB_KEY = JSON.stringify(FLOWX_HB_KEY);

  const script = document.createElement('script');
  script.id = 'flowx-hb-monitor-tag';
  // The IIFE is embedded as a string so it runs in the PAGE context, not the
  // content-script isolated world. sessionStorage is shared between both contexts.
  script.textContent = [
    '(function(){',
    '  var KEY=' + HB_KEY + ';',
    '  var GRACE=' + GRACE_MS + ';',
    '  var TIMEOUT=' + TIMEOUT_MS + ';',
    '  var start=Date.now();',
    '  var tid=setInterval(function(){',
    '    var now=Date.now();',
    '    if(now-start<GRACE) return;',        // still in grace period
    '    var hb=sessionStorage.getItem(KEY);',
    '    if(!hb){',
    '      if(now-start>GRACE+TIMEOUT){',
    '        clearInterval(tid);',
    '        sessionStorage.removeItem(KEY);',
    '        window.location.href="https://accounts.google.com/Logout?continue="+encodeURIComponent("https://flow.google.com");',
    '      }',
    '      return;',
    '    }',
    '    if(now-parseInt(hb,10)>TIMEOUT){',
    '      clearInterval(tid);',
    '      sessionStorage.removeItem(KEY);',
    '      window.location.href="https://accounts.google.com/Logout?continue="+encodeURIComponent("https://flow.google.com");',
    '    }',
    '  },' + CHECK_MS + ');',
    '})();',
  ].join('\n');

  (document.head || document.documentElement).appendChild(script);
  // Remove the tag — the IIFE already started its interval, the tag is no longer needed.
  script.remove();
}

/* ─────────────────────────────────────────────────────────
   SETTINGS UPDATE LISTENER (from popup)
───────────────────────────────────────────────────────── */
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SETTINGS_UPDATED') {
    FLOWX = { ...FLOWX, ...message.settings };

    if (!FLOWX.enabled) {
      // Stop the heartbeat immediately so the page monitor detects it.
      stopHeartbeat();
      // Remove FlowX injected elements.
      ['flowx-banner', 'flowx-watermark', 'flowx-modal-overlay'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.remove();
      });
      // Trigger logout right away — no need to wait for the monitor timeout.
      triggerFlowLogout();
    } else {
      // Re-start heartbeat (extension was re-enabled mid-session).
      startHeartbeat();
      // Update WhatsApp link in modal.
      const waLink = document.getElementById('flowx-modal-whatsapp');
      if (waLink) waLink.href = FLOWX.whatsappLink;
      runTransformations();
    }
  }
});

/* ─────────────────────────────────────────────────────────
   BOOTSTRAP
───────────────────────────────────────────────────────── */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadSettings);
} else {
  loadSettings();
}