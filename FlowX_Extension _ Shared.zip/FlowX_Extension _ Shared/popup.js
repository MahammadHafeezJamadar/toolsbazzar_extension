/* ══════════════════════════════════════════════════════════
   FlowX Popup Script
   Uses Supabase's built-in Auth REST API directly —
   no custom Edge Function needed.

   Flow:
   1. POST /auth/v1/token?grant_type=password  (sign-in)
   2. GET  /rest/v1/users?id=eq.{uid}          (plan data)
   3. Render status screen
══════════════════════════════════════════════════════════ */
'use strict';

/* ── Supabase config ────────────────────────────────────── */
const SUPA_URL  = 'https://uvvexcaqeoyanvafsdrc.supabase.co';
const ANON_KEY  = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV2dmV4Y2FxZW95YW52YWZzZHJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2Mzk2MzMsImV4cCI6MjA4ODIxNTYzM30.Ti2c7aMLxL61i9rxyFXtKVoGTHx-6Xyxi0s_t3gq-oM';

// Built-in Supabase Auth endpoint (no Edge Function required)
const AUTH_URL  = `${SUPA_URL}/auth/v1/token?grant_type=password`;

// Table that holds user plan data
const TABLE_USERS = `${SUPA_URL}/rest/v1/profiles`;

/* ── DOM refs ────────────────────────────────────────────── */
const $ = id => document.getElementById(id);

const screenLogin    = $('screen-login');
const screenStatus   = $('screen-status');
const screenWrongSite= $('screen-wrongsite');

const inpEmail     = $('inp-email');
const inpPassword  = $('inp-password');
const btnLogin     = $('btn-login');
const btnLoginTxt  = $('btn-login-text');
const btnLoginSpin = $('btn-login-spinner');
const loginError   = $('login-error');
const btnTogglePw  = $('btn-toggle-pw');

const userAvatar      = $('user-avatar');
const userName        = $('user-name');
const userEmail       = $('user-email');
const planBadge       = $('plan-badge');
const daysValue       = $('days-value');
const progressBar     = $('progress-bar');
const expiryDate      = $('expiry-date');
const btnLogout       = $('btn-logout');
const btnOpenFlow     = $('btn-open-flow');
const btnReconn       = $('btn-reconnect');

// Denied screen
const screenDenied    = $('screen-denied');
const deniedMsg       = $('denied-msg');
const deniedUser      = $('denied-user');
const btnDeniedLogout = $('btn-denied-logout');

/* ══════════════════════════════════════════════════════════
   INIT — gate on Google Flow URL, then restore session
   Requirement 8: popup functionality blocked on non-Flow tabs
══════════════════════════════════════════════════════════ */
const FLOW_HOSTNAME = 'flow.google.com';

function isFlowTab(url) {
  try { return new URL(url).hostname === FLOW_HOSTNAME; }
  catch { return false; }
}

// Step 1: Check active tab URL
chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  if (!tab || !isFlowTab(tab.url || '')) {
    showScreen('wrongsite');
    return;
  }
  // Step 2: On Flow — restore session or show login
  chrome.storage.local.get(null, stored => {
    if (stored && stored.userId && stored.accessToken) {
      // Re-validate access on every init (plan may have expired since last login)
      const access = checkAccess(stored);
      if (!access.allowed) {
        showDenied(stored, access.message);
      } else {
        renderStatus(stored);
      }
    } else {
      showScreen('login');
    }
  });
});

/* ══════════════════════════════════════════════════════════
   SCREEN SWITCHER
══════════════════════════════════════════════════════════ */
function showScreen(name) {
  screenWrongSite.classList.toggle('hidden', name !== 'wrongsite');
  screenDenied.classList.toggle('hidden',    name !== 'denied');
  screenLogin.classList.toggle('hidden',     name !== 'login');
  screenStatus.classList.toggle('hidden',    name !== 'status');
}

// Wrong-site screen: Open Google Flow button
$('btn-goto-flow').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://flow.google.com' });
});

// Denied screen: logout so user can try another account
btnDeniedLogout.addEventListener('click', () => {
  chrome.storage.local.clear(() => {
    inpEmail.value    = '';
    inpPassword.value = '';
    showScreen('login');
  });
});

/* ══════════════════════════════════════════════════════════
   ACCESS VALIDATOR
   Called after login and on session restore.
   Returns { allowed: bool, message: string }
   Conditions:
     1. Plan must be Active (DB status OR expiry date in future)
     2. Plan type must be 'Private'
══════════════════════════════════════════════════════════ */
function checkAccess(d) {
  // ── Only check: Is plan active / not expired? ──
  // planType (Private/Shared/empty) does NOT affect access.
  // Extension works for ALL account types as long as plan is active.
  let isActive = true;

  // Check DB status flag (if explicitly set to false, block)
  if (d.subscriptionActive === false) isActive = false;

  // Check expiry date — this is the authoritative check
  if (d.expiryDate) {
    try {
      const expiry = new Date(d.expiryDate);
      const today  = new Date();
      today.setHours(0, 0, 0, 0);
      expiry.setHours(0, 0, 0, 0);
      if (expiry < today) isActive = false; // plan has expired
    } catch { /* invalid date — don't block */ }
  }

  if (!isActive) {
    return {
      allowed: false,
      message: 'Your plan is inactive or expired. Please contact Admin.',
    };
  }

  // All other cases → allow
  return { allowed: true, message: '' };
}


function showDenied(d, message) {
  deniedMsg.textContent  = message;
  deniedUser.textContent = d.userEmail ? `Logged in as: ${d.userEmail}` : '';
  showScreen('denied');
}

/* ══════════════════════════════════════════════════════════
   LOGIN HANDLER
══════════════════════════════════════════════════════════ */
btnLogin.addEventListener('click', handleLogin);
[inpEmail, inpPassword].forEach(el =>
  el.addEventListener('keydown', e => { if (e.key === 'Enter') handleLogin(); })
);

async function handleLogin() {
  const email    = inpEmail.value.trim();
  const password = inpPassword.value;

  if (!email || !password) { showError('Please enter your email and password.'); return; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showError('Please enter a valid email address.'); return; }

  setLoading(true);
  hideError();

  try {
    /* ── STEP 1: Authenticate with Supabase Auth ── */
    const authRes = await fetch(AUTH_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': ANON_KEY,
      },
      body: JSON.stringify({ email, password }),
    });

    const authData = await authRes.json().catch(() => ({}));

    if (!authRes.ok) {
      // Supabase returns error_description for auth failures
      const msg = authData?.error_description || authData?.message || authData?.error;
      if (msg && (msg.toLowerCase().includes('invalid') || msg.toLowerCase().includes('credentials'))) {
        showError('Invalid email or password. Please try again.');
      } else {
        showError(msg || 'Login failed. Please try again.');
      }
      setLoading(false);
      return;
    }

    const accessToken = authData.access_token;
    const userId      = authData.user?.id || '';
    const authEmail   = authData.user?.email || email;

    /* ── STEP 2: Fetch user's plan data from users table ── */
    let planData = {};
    try {
      const userRes = await fetch(
        `${TABLE_USERS}?select=*&id=eq.${encodeURIComponent(userId)}`,
        {
          headers: {
            'apikey': ANON_KEY,
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (userRes.ok) {
        const rows = await userRes.json();
        if (Array.isArray(rows) && rows.length > 0) {
          planData = rows[0];
        }
      }
    } catch (_) {
      // Plan data fetch failed — still allow login, show what we have
    }

    /* ── STEP 3: Normalise field names (Lovable/Supabase naming varies) ── */
    const toSave = {
      userId,
      accessToken,
      userName:           pick(planData, ['name','full_name','display_name','user_name']) ||
                          authData.user?.user_metadata?.full_name || authEmail.split('@')[0],
      userEmail:          pick(planData, ['email']) || authEmail,
      plan:               pick(planData, ['plan','plan_name','subscription_plan','tier']) || 'Starter',
      // Plan type: 'Private' or 'Shared' — admin-set field
      planType:           pick(planData, ['plan_type','type','account_type','subscription_type',
                                          'user_type','planType','accountType']) || '',
      // Subscription active flag from DB (expiry date is also checked in checkAccess)
      subscriptionActive: pickBool(planData,
                            ['subscription_active','is_active','active','status'],
                            v => typeof v === 'boolean' ? v : /active|true/i.test(String(v))),
      // Expiry date — used for auto-calculated remaining days + access check
      expiryDate:         pick(planData, ['expiry_date','plan_expiry','expires_at',
                                          'subscription_end','plan_expiry_date','end_date']) || '',
      planStartDate:      pick(planData, ['start_date','plan_start','plan_start_date',
                                          'subscription_start','created_at']) || '',
    };

    chrome.storage.local.set(toSave, () => {
      setLoading(false);
      // ── ACCESS GATE ──
      const access = checkAccess(toSave);
      if (!access.allowed) {
        showDenied(toSave, access.message);
      } else {
        renderStatus(toSave);
      }
    });

  } catch (err) {
    showError('Connection failed. Check your internet and try again.');
    setLoading(false);
  }
}

/* ── Field-picking helpers ───────────────────────────────── */
function pick(obj, keys) {
  for (const k of keys) {
    if (obj[k] !== undefined && obj[k] !== null && obj[k] !== '') return String(obj[k]);
  }
  return '';
}
function pickBool(obj, keys, transform) {
  for (const k of keys) {
    if (obj[k] !== undefined && obj[k] !== null) return transform(obj[k]);
  }
  return true; // default active
}

/* ══════════════════════════════════════════════════════════
   RENDER STATUS SCREEN
══════════════════════════════════════════════════════════ */
function renderStatus(d) {
  // ── Avatar + name + email ──
  const initials = (d.userName || d.userEmail || '?')
    .split(/[\s.@_-]+/).map(w => w[0] || '').join('').slice(0, 2).toUpperCase() || '?';
  userAvatar.textContent = initials;
  userName.textContent   = d.userName  || '—';
  userEmail.textContent  = d.userEmail || '—';

  // ── Plan badge (plan name) ──
  const plan = (d.plan || 'Starter').trim();
  planBadge.textContent = plan.toUpperCase();
  planBadge.className   = 'plan-badge ' + getPlanClass(plan);

  // ── Remaining Days — auto-calculated from expiryDate ──
  let calcDays = null;
  if (d.expiryDate) {
    try {
      const expiry  = new Date(d.expiryDate);
      // Compare date-only (strip time component) so 'today' = 0 days
      const today   = new Date();
      today.setHours(0, 0, 0, 0);
      expiry.setHours(0, 0, 0, 0);
      calcDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    } catch { calcDays = null; }
  }

  if (calcDays === null) {
    daysValue.textContent   = '—';
    progressBar.style.width = '0%';
    progressBar.className   = 'progress-bar progress-red';
  } else if (calcDays <= 0) {
    daysValue.textContent   = 'Expired';
    progressBar.style.width = '0%';
    progressBar.className   = 'progress-bar progress-red';
  } else {
    daysValue.textContent   = calcDays === 1 ? '1 Day' : `${calcDays} Days`;
    const total = getTotalDays(d.plan);
    const pct   = total > 0 ? Math.min(100, Math.round((calcDays / total) * 100)) : 50;
    progressBar.style.width = `${pct}%`;
    progressBar.className   = 'progress-bar ' + getProgressClass(pct);
  }

  // ── Expiry Date (formatted) ──
  if (d.expiryDate) {
    try {
      expiryDate.textContent = new Date(d.expiryDate).toLocaleDateString('en-GB', {
        day: '2-digit', month: 'short', year: 'numeric',
      });
    } catch { expiryDate.textContent = d.expiryDate; }
  } else {
    expiryDate.textContent = '—';
  }

  showScreen('status');
}

/* ── Helpers ────────────────────────────────────────────── */
function getPlanClass(plan) {
  const p = plan.toLowerCase();
  if (p.includes('ultra')) return 'plan-ultra';
  if (p.includes('pro'))   return 'plan-pro';
  if (p.includes('start')) return 'plan-starter';
  return 'plan-default';
}
function getProgressClass(pct) {
  if (pct > 40) return 'progress-green';
  if (pct > 15) return 'progress-orange';
  return 'progress-red';
}
function getTotalDays(plan) {
  const p = (plan || '').toLowerCase();
  if (p.includes('year') || p.includes('annual')) return 365;
  return 30;
}

/* ══════════════════════════════════════════════════════════
   LOGOUT
══════════════════════════════════════════════════════════ */
btnLogout.addEventListener('click', () => {
  chrome.storage.local.clear(() => {
    inpEmail.value    = '';
    inpPassword.value = '';
    hideError();
    showScreen('login');
  });
});

/* ══════════════════════════════════════════════════════════
   RECONNECT — refresh plan data using stored token
══════════════════════════════════════════════════════════ */
btnReconn.addEventListener('click', async () => {
  chrome.storage.local.get(null, async stored => {
    if (!stored?.userId || !stored?.accessToken) { showScreen('login'); return; }

    try {
      const res = await fetch(
        `${TABLE_USERS}?select=*&id=eq.${encodeURIComponent(stored.userId)}`,
        {
          headers: {
            'apikey': ANON_KEY,
            'Authorization': `Bearer ${stored.accessToken}`,
          },
        }
      );
      if (res.ok) {
        const rows = await res.json();
        if (Array.isArray(rows) && rows.length > 0) {
          const planData = rows[0];
          const updated  = {
            ...stored,
            plan:               pick(planData, ['plan','plan_name','subscription_plan','tier']) || stored.plan,
            planType:           pick(planData, ['plan_type','type','account_type','subscription_type',
                                                'user_type','planType','accountType']) || stored.planType,
            subscriptionActive: pickBool(planData, ['subscription_active','is_active','active','status'],
                                          v => typeof v === 'boolean' ? v : /active|true/i.test(String(v))),
            expiryDate:         pick(planData, ['expiry_date','plan_expiry','expires_at','subscription_end',
                                                'plan_expiry_date','end_date']) || stored.expiryDate,
            planStartDate:      pick(planData, ['start_date','plan_start','plan_start_date',
                                                'subscription_start','created_at']) || stored.planStartDate,
          };
          chrome.storage.local.set(updated, () => {
            // Re-validate access with freshly fetched plan data
            const access = checkAccess(updated);
            if (!access.allowed) {
              showDenied(updated, access.message);
            } else {
              renderStatus(updated);
            }
          });
          return;
        }
      }
    } catch (_) {}
    // If refresh fails, just re-render with cached data
    renderStatus(stored);
  });
});

/* ══════════════════════════════════════════════════════════
   OPEN GOOGLE FLOW
══════════════════════════════════════════════════════════ */
btnOpenFlow.addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://flow.google.com' });
});

/* ══════════════════════════════════════════════════════════
   PASSWORD VISIBILITY TOGGLE
══════════════════════════════════════════════════════════ */
btnTogglePw.addEventListener('click', () => {
  const isPass = inpPassword.type === 'password';
  inpPassword.type = isPass ? 'text' : 'password';
  $('eye-icon').style.opacity = isPass ? '0.45' : '1';
});

/* ══════════════════════════════════════════════════════════
   UI HELPERS
══════════════════════════════════════════════════════════ */
function setLoading(on) {
  btnLogin.disabled       = on;
  btnLoginTxt.textContent = on ? 'Signing in…' : 'Login';
  btnLoginSpin.classList.toggle('hidden', !on);
}
function showError(msg) {
  loginError.textContent = msg;
  loginError.classList.remove('hidden');
}
function hideError() {
  loginError.classList.add('hidden');
  loginError.textContent = '';
}
