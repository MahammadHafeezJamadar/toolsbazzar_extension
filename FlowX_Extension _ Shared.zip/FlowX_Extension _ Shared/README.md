# ⚡ FlowX Chrome Extension

**Automatic overlay for Google Flow — Zero cookies, zero server, zero tension!**

---

## 🚀 Features

| Feature | Description |
|---|---|
| **Model Rename** | `Lite` → `Fast` · `Fast` → `Quality` |
| **Credits Hidden** | Credits UI replaced with "Contact Admin" button |
| **Contact Admin** | WhatsApp popup with your admin's number |
| **FlowX Branding** | Black/Silver Chrome premium theme |
| **Unified Next Button** | Enhanced → generate button with glow effect |
| **Auto Detection** | Works automatically on all `flow.google.com` pages |

---

## 📦 Install Instructions

### Step 1 — Generate Icons

1. Open `icons/gen_icons.html` in Chrome browser
2. Click **"Download All Icons"**
3. Save the 4 PNG files into `icons/` folder:
   - `icon16.png`
   - `icon32.png`
   - `icon48.png`
   - `icon128.png`

### Step 2 — Load in Chrome

1. Open Chrome → go to `chrome://extensions`
2. Enable **"Developer mode"** (top right toggle)
3. Click **"Load unpacked"**
4. Select this `FlowX_Extension` folder
5. Done! ✅

### Step 3 — Configure Admin WhatsApp

1. Click the FlowX icon in Chrome toolbar
2. Enter your WhatsApp number (without +)
3. Click **Save Settings**

---

## 📁 File Structure

```
FlowX_Extension/
├── manifest.json      ← Extension config
├── content.js         ← Main injection script
├── content.css        ← Theme & UI styles
├── popup.html         ← Extension popup
├── popup.js           ← Popup logic
├── popup.css          ← Popup styles
├── background.js      ← Service worker
└── icons/
    ├── gen_icons.html ← Icon generator (run once)
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png
```

---

## 🔧 Customization

Edit `content.js` → `FLOWX` config object at the top:
- `whatsappNumber` — Admin WhatsApp number
- `whatsappLink` — Full wa.me link

Edit `TEXT_RULES` array to change any text replacements.

---

## ⚡ How It Works

```
User opens flow.google.com
         ↓
Extension automatically detects the page
         ↓
MutationObserver watches ALL DOM changes (SPA-safe)
         ↓
✅ Text replaced: Lite→Fast, Fast→Quality
✅ Credits UI hidden → Contact Admin injected
✅ FlowX theme applied
✅ → button enhanced
```

---

*FlowX — Made for FlowX Premium users*
